# CppEditor

Online C++ editor + compiler built with Next.js App Router, TypeScript, TailwindCSS and Docker.

## Features

- Monaco editor for `main.cpp`
- Input editor for `input.txt`
- Compile and run C++20 using `g++`
- Share link with LZMA + base64url in `/s/[compressedData]`
- Autosave to localStorage with LZMA
- Single Docker service, no docker-compose

## Run locally

```bash
npm install
npm run dev
```

## Docker

```bash
docker build -t cppeditor .
docker run -p 3000:3000 cppeditor
```
