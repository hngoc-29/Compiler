import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        card: 'hsl(var(--card))',
        muted: 'hsl(var(--muted))',
        accent: 'hsl(var(--accent))',
        panel: 'hsl(var(--panel))',
      },
      boxShadow: {
        soft: '0 12px 40px rgba(0, 0, 0, 0.18)',
      },
    },
  },
  plugins: [],
};

export default config;
