import { EditorWorkspace } from '@/components/editor-workspace';

type PageProps = {
  params: {
    compressedData: string;
  };
};

export default function SharePage({ params }: PageProps) {
  return <EditorWorkspace mode="share" compressedData={params.compressedData} />;
}
