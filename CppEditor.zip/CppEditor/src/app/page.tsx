import { EditorWorkspace } from '@/components/editor-workspace';

export default function HomePage() {
  return <EditorWorkspace mode="home" />;
}
