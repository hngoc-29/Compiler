import { mkdtemp, writeFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { execFile, spawn } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type RunRequest = {
  code?: string;
  input?: string;
};

type RunResponse = {
  success: boolean;
  compileLog: string;
  stdout: string;
  stderr: string;
  runtimeMs: number;
  exitCode: number | null;
  timedOut: boolean;
};

function toText(value: unknown): string {
  if (typeof value === 'string') return value;
  if (value instanceof Uint8Array) return new TextDecoder().decode(value);
  return '';
}

function normalizeError(err: unknown): { stdout: string; stderr: string; timedOut: boolean; exitCode: number | null } {
  if (!err || typeof err !== 'object') {
    return { stdout: '', stderr: 'Unknown error', timedOut: false, exitCode: null };
  }

  const e = err as {
    stdout?: unknown;
    stderr?: unknown;
    killed?: boolean;
    signal?: string | null;
    code?: number | string | null;
    message?: string;
  };

  const timedOut = Boolean(e.killed) || e.signal === 'SIGTERM';
  const exitCode = typeof e.code === 'number' ? e.code : null;

  return {
    stdout: toText(e.stdout),
    stderr: toText(e.stderr) || e.message || 'Execution failed',
    timedOut,
    exitCode,
  };
}


function runExecutable(executable: string, cwd: string, input: string, timeoutMs: number): Promise<{ stdout: string; stderr: string; exitCode: number | null; timedOut: boolean }> {
  return new Promise((resolve) => {
    const child = spawn(executable, [], {
      cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let finished = false;
    const timeout = setTimeout(() => {
      if (finished) return;
      finished = true;
      child.kill('SIGKILL');
      resolve({
        stdout,
        stderr: stderr || 'Execution timed out.',
        exitCode: null,
        timedOut: true,
      });
    }, timeoutMs);

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');

    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });

    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });

    child.on('error', (error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      resolve({
        stdout,
        stderr: stderr || (error instanceof Error ? error.message : 'Execution failed'),
        exitCode: null,
        timedOut: false,
      });
    });

    child.on('close', (code, signal) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      resolve({
        stdout,
        stderr,
        exitCode: typeof code === 'number' ? code : null,
        timedOut: signal === 'SIGKILL',
      });
    });

    child.stdin.end(input);
  });
}

async function runCpp(code: string, input: string): Promise<RunResponse> {
  const workDir = await mkdtemp(join(tmpdir(), 'cppeditor-'));
  const sourcePath = join(workDir, 'main.cpp');
  const inputPath = join(workDir, 'input.txt');
  const outputExe = join(workDir, process.platform === 'win32' ? 'main.exe' : 'main');

  const started = process.hrtime.bigint();

  try {
    await writeFile(sourcePath, code, 'utf8');
    await writeFile(inputPath, input, 'utf8');

    try {
      const compile = await execFileAsync(
        'g++',
        ['-std=c++20', '-O2', '-pipe', '-o', outputExe, sourcePath],
        {
          cwd: workDir,
          timeout: 10000,
          maxBuffer: 2 * 1024 * 1024,
        }
      );

      const runtimeStarted = process.hrtime.bigint();

      const run = await runExecutable(outputExe, workDir, input, 10000);
      const runtimeMs = Number(process.hrtime.bigint() - runtimeStarted) / 1_000_000;

      return {
        success: run.exitCode === 0 && !run.timedOut,
        compileLog: `${toText(compile.stdout)}${toText(compile.stderr)}`.trim(),
        stdout: run.stdout,
        stderr: run.stderr,
        runtimeMs,
        exitCode: run.exitCode,
        timedOut: run.timedOut,
      };
    } catch (compileErr) {
      const normalized = normalizeError(compileErr);
      const runtimeMs = Number(process.hrtime.bigint() - started) / 1_000_000;
      return {
        success: false,
        compileLog: `${normalized.stdout}${normalized.stderr}`.trim() || 'Compilation failed',
        stdout: '',
        stderr: normalized.stderr,
        runtimeMs,
        exitCode: normalized.exitCode,
        timedOut: normalized.timedOut,
      };
    }
  } finally {
    await rm(workDir, { recursive: true, force: true });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as RunRequest;
    const code = typeof body.code === 'string' ? body.code : '';
    const input = typeof body.input === 'string' ? body.input : '';

    if (!code.trim()) {
      return Response.json<RunResponse>(
        {
          success: false,
          compileLog: 'Source code is empty.',
          stdout: '',
          stderr: '',
          runtimeMs: 0,
          exitCode: null,
          timedOut: false,
        },
        { status: 400 }
      );
    }

    const result = await runCpp(code, input);
    return Response.json(result);
  } catch (error) {
    return Response.json<RunResponse>(
      {
        success: false,
        compileLog: 'Server error while running compiler.',
        stdout: '',
        stderr: error instanceof Error ? error.message : 'Unknown server error',
        runtimeMs: 0,
        exitCode: null,
        timedOut: false,
      },
      { status: 500 }
    );
  }
}
