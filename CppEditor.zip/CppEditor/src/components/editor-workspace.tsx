'use client';

import dynamic from 'next/dynamic';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ClipboardCopy, Download, FileCode2, Loader2, Play, Share2, Terminal, X } from 'lucide-react';
import type * as MonacoType from 'monaco-editor';
import { decodeSharePayload, encodeSharePayload, loadWorkspaceFromLocalStorage, saveWorkspaceToLocalStorage } from '@/lib/storage';
import type { EditorPayload, RunResult } from '@/lib/types';

const MonacoEditor = dynamic(() => import('@monaco-editor/react'), { ssr: false });

type WorkspaceMode = 'home' | 'share';

type Props = {
  mode: WorkspaceMode;
  compressedData?: string;
};

const DEFAULT_CODE = `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (cin >> n) {
        cout << n * 2 << '\\n';
    } else {
        cout << "Hello from CppEditor!\\n";
    }
    return 0;
}
`;

const DEFAULT_INPUT = `5
`;

const EMPTY_RUN: RunResult = {
  success: false,
  compileLog: '',
  stdout: '',
  stderr: '',
  runtimeMs: 0,
  exitCode: null,
  timedOut: false,
};

type OutputTab = 'stdout' | 'stderr' | 'compile' | 'meta';

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ');
}

function EditorCard({
  title,
  subtitle,
  children,
  right,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  right?: React.ReactNode;
}) {
  return (
    <section className="flex min-h-0 flex-col overflow-hidden rounded-3xl border border-white/10 bg-white/5 shadow-soft backdrop-blur">
      <header className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
        <div>
          <h2 className="text-sm font-semibold tracking-wide text-white">{title}</h2>
          <p className="text-xs text-slate-400">{subtitle}</p>
        </div>
        {right}
      </header>
      <div className="min-h-0 flex-1">{children}</div>
    </section>
  );
}

function ActionButton({
  onClick,
  children,
  icon,
  disabled,
  className,
  title,
}: {
  onClick: () => void;
  children: React.ReactNode;
  icon?: React.ReactNode;
  disabled?: boolean;
  className?: string;
  title?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-50',
        className
      )}
    >
      {icon}
      <span>{children}</span>
    </button>
  );
}

function DownloadRow({
  defaultName,
  label,
  content,
}: {
  defaultName: string;
  label: string;
  content: string;
}) {
  const [filename, setFilename] = useState(defaultName);

  useEffect(() => {
    setFilename(defaultName);
  }, [defaultName]);

  const download = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename.trim() || defaultName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
      <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">{label}</div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <input
          value={filename}
          onChange={(e) => setFilename(e.target.value)}
          className="w-full rounded-2xl border border-white/10 bg-slate-950/70 px-3 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-sky-500"
          placeholder={defaultName}
        />
        <button
          type="button"
          onClick={download}
          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-sky-500/20 px-4 py-2 text-sm font-medium text-sky-200 transition hover:bg-sky-500/30"
        >
          <Download className="h-4 w-4" />
          Download
        </button>
      </div>
    </div>
  );
}

function ExportMenu({
  code,
  input,
  output,
}: {
  code: string;
  input: string;
  output: string;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <ActionButton onClick={() => setOpen((v) => !v)} icon={<Download className="h-4 w-4" />} title="Export">
        Export
      </ActionButton>

      {open ? (
        <div className="absolute right-0 z-30 mt-3 w-[min(92vw,420px)] rounded-3xl border border-white/10 bg-slate-950/95 p-4 shadow-soft backdrop-blur-xl">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-white">Export files</div>
              <div className="text-xs text-slate-400">Rename each file before downloading.</div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-full p-2 text-slate-400 transition hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="space-y-3">
            <DownloadRow defaultName="main.cpp" label="Code" content={code} />
            <DownloadRow defaultName="input.txt" label="Input" content={input} />
            <DownloadRow defaultName="output.txt" label="Output" content={output} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function OutputTabs({ runResult }: { runResult: RunResult }) {
  const [tab, setTab] = useState<OutputTab>('stdout');

  const content = useMemo(() => {
    if (tab === 'stdout') return runResult.stdout || 'No stdout output yet.';
    if (tab === 'stderr') return runResult.stderr || 'No stderr output yet.';
    if (tab === 'compile') return runResult.compileLog || 'No compile log yet.';
    return [
      `Success: ${runResult.success ? 'yes' : 'no'}`,
      `Exit code: ${runResult.exitCode ?? 'n/a'}`,
      `Timed out: ${runResult.timedOut ? 'yes' : 'no'}`,
      `Runtime: ${runResult.runtimeMs ? `${runResult.runtimeMs.toFixed(2)} ms` : 'n/a'}`,
    ].join('\n');
  }, [runResult, tab]);

  const tabs: Array<{ key: OutputTab; label: string }> = [
    { key: 'stdout', label: 'stdout' },
    { key: 'stderr', label: 'stderr' },
    { key: 'compile', label: 'compile log' },
    { key: 'meta', label: 'metadata' },
  ];

  return (
    <EditorCard
      title="Output"
      subtitle="stdout, stderr, compile log and run metadata"
      right={<Terminal className="h-4 w-4 text-sky-300" />}
    >
      <div className="flex h-full min-h-[320px] flex-col">
        <div className="flex gap-2 border-b border-white/10 px-4 py-3">
          {tabs.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setTab(item.key)}
              className={cn(
                'rounded-full px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] transition',
                tab === item.key ? 'bg-sky-500/25 text-sky-200' : 'text-slate-400 hover:bg-white/5 hover:text-white'
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
        <pre className="scrollbar-thin min-h-0 flex-1 overflow-auto px-4 py-4 text-sm leading-6 text-slate-100">
          {content}
        </pre>
      </div>
    </EditorCard>
  );
}

export function EditorWorkspace({ mode, compressedData }: Props) {
  const router = useRouter();
  const [code, setCode] = useState(DEFAULT_CODE);
  const [input, setInput] = useState(DEFAULT_INPUT);
  const [runResult, setRunResult] = useState<RunResult>(EMPTY_RUN);
  const [running, setRunning] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [loaded, setLoaded] = useState(false);
  const saveTimer = useRef<number | null>(null);
  const saveToken = useRef(0);

  const currentPayload = useMemo<EditorPayload>(() => ({ code, input }), [code, input]);

  useEffect(() => {
    let active = true;

    async function hydrate() {
      const shared = mode === 'share' && compressedData ? await decodeSharePayload(compressedData) : null;
      if (!active) return;

      if (shared) {
        setCode(shared.code || DEFAULT_CODE);
        setInput(shared.input || '');
      } else {
        const stored = await loadWorkspaceFromLocalStorage();
        if (!active) return;
        if (stored) {
          setCode(stored.code || DEFAULT_CODE);
          setInput(stored.input || '');
        }
      }

      setLoaded(true);
    }

    hydrate();
    return () => {
      active = false;
    };
  }, [compressedData, mode]);

  useEffect(() => {
    if (!loaded) return;
    if (saveTimer.current) window.clearTimeout(saveTimer.current);

    const token = ++saveToken.current;
    saveTimer.current = window.setTimeout(() => {
      void (async () => {
        try {
          if (saveToken.current !== token) return;
          await saveWorkspaceToLocalStorage(currentPayload);
        } catch {
          // ignored intentionally
        }
      })();
    }, 800);

    return () => {
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
    };
  }, [currentPayload, loaded]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if ((event.metaKey || event.ctrlKey) && key === 'enter') {
        event.preventDefault();
        void runCode();
      }
    };

    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  async function runCode() {
    if (running) return;
    setRunning(true);
    try {
      const response = await fetch('/api/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(currentPayload),
      });

      const data = (await response.json()) as RunResult;
      setRunResult(data);
    } catch (error) {
      setRunResult({
        success: false,
        compileLog: 'Failed to contact compiler service.',
        stdout: '',
        stderr: error instanceof Error ? error.message : 'Unknown error',
        runtimeMs: 0,
        exitCode: null,
        timedOut: false,
      });
    } finally {
      setRunning(false);
    }
  }

  async function handleShare() {
    setSharing(true);
    try {
      const compressed = await encodeSharePayload(currentPayload);
      const url = `${window.location.origin}/s/${compressed}`;
      setShareUrl(url);
      await navigator.clipboard.writeText(url);
      router.push(`/s/${compressed}`);
    } catch {
      setShareUrl('');
    } finally {
      setSharing(false);
    }
  }

  const editorOptions = useMemo(
    () => ({
      fontSize: 14,
      minimap: { enabled: false },
      automaticLayout: true,
      scrollBeyondLastLine: false,
      wordWrap: 'on' as const,
      tabSize: 4,
      insertSpaces: true,
      smoothScrolling: true,
      padding: { top: 16, bottom: 16 },
      renderWhitespace: 'selection' as const,
      fontLigatures: true,
    }),
    []
  );

  const onEditorMount = (
    editor: MonacoType.editor.IStandaloneCodeEditor,
    monaco: typeof import('monaco-editor')
  ) => {
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      void runCode();
    });
  };

  return (
    <main className="min-h-screen text-white">
      <div className="mx-auto flex min-h-screen w-full max-w-[1800px] flex-col gap-4 p-3 sm:p-4 lg:p-6">
        <header className="rounded-3xl border border-white/10 bg-white/5 px-4 py-4 shadow-soft backdrop-blur">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl border border-sky-400/20 bg-sky-500/15 p-3">
                <FileCode2 className="h-6 w-6 text-sky-300" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">CppEditor</h1>
                <p className="mt-1 max-w-2xl text-sm text-slate-400">
                  Online C++ editor, compiler, share link and autosave with LZMA compression.
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
              <ActionButton onClick={() => void runCode()} icon={running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />} disabled={running}>
                Run
              </ActionButton>
              <ActionButton onClick={() => void handleShare()} icon={sharing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Share2 className="h-4 w-4" />} disabled={sharing}>
                Share
              </ActionButton>
              <ExportMenu code={code} input={input} output={runResult.stdout} />
            </div>
          </div>

          <div className="mt-4 flex flex-col gap-2 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-slate-300">
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                Autosave enabled
              </span>
              <span className="text-slate-400">Ctrl/Cmd + Enter to run</span>
            </div>
            {shareUrl ? (
              <div className="mt-1 flex flex-col gap-2 sm:flex-row">
                <input
                  readOnly
                  value={shareUrl}
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/70 px-3 py-2 text-sm text-white outline-none"
                />
                <button
                  type="button"
                  onClick={() => void navigator.clipboard.writeText(shareUrl)}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/15"
                >
                  <ClipboardCopy className="h-4 w-4" />
                  Copy
                </button>
              </div>
            ) : null}
          </div>
        </header>

        <section className="grid min-h-0 flex-1 grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1.2fr)_minmax(320px,0.8fr)]">
          <div className="grid min-h-0 grid-cols-1 gap-4 lg:grid-cols-2">
            <EditorCard title="Code Editor" subtitle="main.cpp - C++20 source code" right={<span className="text-xs text-slate-400">main.cpp</span>}>
              <div className="h-[460px] min-h-[460px] lg:h-full">
                <MonacoEditor
                  language="cpp"
                  theme="vs-dark"
                  value={code}
                  onChange={(value) => setCode(value ?? '')}
                  options={editorOptions}
                  onMount={onEditorMount}
                  loading={<div className="p-4 text-sm text-slate-400">Loading editor…</div>}
                />
              </div>
            </EditorCard>

            <EditorCard title="Input Editor" subtitle="input.txt - stdin content" right={<span className="text-xs text-slate-400">input.txt</span>}>
              <div className="h-[460px] min-h-[460px] lg:h-full">
                <MonacoEditor
                  language="plaintext"
                  theme="vs-dark"
                  value={input}
                  onChange={(value) => setInput(value ?? '')}
                  options={editorOptions}
                  onMount={onEditorMount}
                  loading={<div className="p-4 text-sm text-slate-400">Loading editor…</div>}
                />
              </div>
            </EditorCard>
          </div>

          <div className="min-h-0">
            <OutputTabs runResult={runResult} />
          </div>
        </section>
      </div>
    </main>
  );
}

