export type EditorPayload = {
  code: string;
  input: string;
};

export type RunResult = {
  success: boolean;
  compileLog: string;
  stdout: string;
  stderr: string;
  runtimeMs: number;
  exitCode: number | null;
  timedOut: boolean;
};
