'use client';

import { compress, decompress } from 'lzma-web';

function toUint8Array(data: unknown): Uint8Array {
  if (data instanceof Uint8Array) return data;
  if (typeof ArrayBuffer !== 'undefined' && data instanceof ArrayBuffer) return new Uint8Array(data);
  if (Array.isArray(data)) return Uint8Array.from(data.map((v) => Number(v) & 255));
  if (typeof data === 'string') return new TextEncoder().encode(data);
  return new Uint8Array();
}

export function base64UrlEncode(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;

  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }

  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

export function base64UrlDecode(text: string): Uint8Array {
  const base64 = text.replace(/-/g, '+').replace(/_/g, '/');
  const pad = (4 - (base64.length % 4)) % 4;
  const normalized = base64 + '='.repeat(pad);
  const binary = atob(normalized);
  const bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }

  return bytes;
}

export async function compressToBase64Url(value: string, level = 9): Promise<string> {
  const compressed = await compress(value, level);
  return base64UrlEncode(toUint8Array(compressed));
}

export async function decompressFromBase64Url(value: string): Promise<string> {
  const decoded = base64UrlDecode(value);
  const raw = await decompress(decoded);
  if (typeof raw === 'string') return raw;
  return new TextDecoder().decode(toUint8Array(raw));
}

export function safeParseEditorPayload(input: string): { code: string; input: string } | null {
  try {
    const parsed = JSON.parse(input) as Partial<{ code: string; input: string }>;
    return {
      code: typeof parsed.code === 'string' ? parsed.code : '',
      input: typeof parsed.input === 'string' ? parsed.input : '',
    };
  } catch {
    return null;
  }
}
