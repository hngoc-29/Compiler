'use client';

import { compressToBase64Url, decompressFromBase64Url, safeParseEditorPayload } from '@/lib/lzma';
import type { EditorPayload } from '@/lib/types';

const STORAGE_KEY = 'cppeditor.workspace.v1';

export async function saveWorkspaceToLocalStorage(payload: EditorPayload): Promise<void> {
  if (typeof window === 'undefined') return;
  const packed = JSON.stringify(payload);
  const compressed = await compressToBase64Url(packed, 9);
  window.localStorage.setItem(STORAGE_KEY, compressed);
}

export async function loadWorkspaceFromLocalStorage(): Promise<EditorPayload | null> {
  if (typeof window === 'undefined') return null;
  const compressed = window.localStorage.getItem(STORAGE_KEY);
  if (!compressed) return null;
  try {
    const packed = await decompressFromBase64Url(compressed);
    return safeParseEditorPayload(packed);
  } catch {
    return null;
  }
}

export async function encodeSharePayload(payload: EditorPayload): Promise<string> {
  const json = JSON.stringify(payload);
  return compressToBase64Url(json, 9);
}

export async function decodeSharePayload(encoded: string): Promise<EditorPayload | null> {
  try {
    const json = await decompressFromBase64Url(encoded);
    return safeParseEditorPayload(json);
  } catch {
    return null;
  }
}
