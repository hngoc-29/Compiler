// next.config.mjs
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Bắt buộc để build standalone image cho Docker
  output: 'standalone',

  // Cấu hình webpack để hỗ trợ lzma-web trong browser
  webpack: (config, { isServer }) => {
    if (!isServer) {
      // Tránh import các module Node.js không cần trong browser
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        path: false,
        os: false,
        crypto: false,
        stream: false,
        child_process: false,
      };
    }
    return config;
  },
};

export default nextConfig;