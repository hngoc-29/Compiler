// components/OutputPanel.tsx
'use client';

/**
 * Panel hiển thị kết quả compile và chạy C++.
 * Chia thành 3 tab: Output, Errors, Info.
 */

import { useState } from 'react';
import { Copy, Trash2, Terminal, AlertCircle, Info, Loader2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { formatDuration } from '@/lib/utils';

interface CompileResult {
  stdout: string;
  stderr: string;
  compileError: string | null;
  exitCode: number;
  runtime: number;
  timedOut: boolean;
}

interface OutputPanelProps {
  result: CompileResult | null;
  isLoading: boolean;
  onClear: () => void;
}

type TabId = 'output' | 'errors' | 'info';

export default function OutputPanel({ result, isLoading, onClear }: OutputPanelProps) {
  const [activeTab, setActiveTab] = useState<TabId>('output');

  // Số lỗi (compile + runtime stderr)
  const errorCount = result
    ? (result.compileError ? 1 : 0) + (result.stderr ? 1 : 0)
    : 0;

  // Copy nội dung tab hiện tại
  const handleCopy = async () => {
    let content = '';
    if (!result) return;

    switch (activeTab) {
      case 'output':
        content = result.stdout || '(no output)';
        break;
      case 'errors':
        content = [result.compileError, result.stderr].filter(Boolean).join('\n\n') || '(no errors)';
        break;
      case 'info':
        content = [
          `Exit code: ${result.exitCode}`,
          `Runtime: ${formatDuration(result.runtime)}`,
          result.timedOut ? 'Status: TIMED OUT' : `Status: ${result.exitCode === 0 ? 'OK' : 'ERROR'}`,
          result.compileError ? 'Compile: FAILED' : 'Compile: OK',
        ].join('\n');
        break;
    }

    try {
      await navigator.clipboard.writeText(content);
      toast.success('Đã copy!');
    } catch {
      toast.error('Không thể copy');
    }
  };

  // Xác định màu status badge
  const getStatusBadge = () => {
    if (!result) return null;
    if (result.compileError) {
      return (
        <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-red-900/40 text-red-400">
          <XCircle size={10} /> Compile Error
        </span>
      );
    }
    if (result.timedOut) {
      return (
        <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-yellow-900/40 text-yellow-400">
          <Clock size={10} /> Timeout
        </span>
      );
    }
    if (result.exitCode !== 0) {
      return (
        <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-orange-900/40 text-orange-400">
          <XCircle size={10} /> Exit {result.exitCode}
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-green-900/40 text-green-400">
        <CheckCircle size={10} /> OK · {formatDuration(result.runtime)}
      </span>
    );
  };

  const tabs: { id: TabId; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'output',
      label: 'Output',
      icon: <Terminal size={12} />,
    },
    {
      id: 'errors',
      label: 'Errors',
      icon: <AlertCircle size={12} />,
      badge: errorCount > 0 ? errorCount : undefined,
    },
    {
      id: 'info',
      label: 'Info',
      icon: <Info size={12} />,
    },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Tab bar + actions */}
      <div className="flex items-center justify-between px-2 py-1 bg-[#111118] border-b border-editor-border shrink-0">
        {/* Tabs */}
        <div className="flex items-center gap-0.5">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs rounded transition-colors ${
                activeTab === tab.id
                  ? 'bg-gray-700 text-gray-100'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800'
              }`}
            >
              {tab.icon}
              {tab.label}
              {tab.badge !== undefined && (
                <span className="ml-0.5 px-1 py-0 rounded-full bg-red-600 text-white text-[9px] leading-4">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          {result && getStatusBadge()}
          {result && (
            <button
              onClick={handleCopy}
              className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
              title="Copy output"
            >
              <Copy size={12} />
            </button>
          )}
          <button
            onClick={onClear}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title="Xóa output"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-[#0d0d15]">
        {/* Loading state */}
        {isLoading && (
          <div className="flex items-center gap-3 p-4 text-gray-400">
            <Loader2 size={16} className="animate-spin text-indigo-400 shrink-0" />
            <span className="text-sm output-loading">Đang compile và chạy...</span>
          </div>
        )}

        {/* Empty state */}
        {!isLoading && !result && (
          <div className="flex flex-col items-center justify-center h-full text-gray-600 gap-2 p-8">
            <Terminal size={32} className="opacity-30" />
            <p className="text-sm text-center">
              Nhấn <kbd className="px-1.5 py-0.5 text-xs bg-gray-800 text-gray-400 rounded border border-gray-700">Run</kbd>
              {' '}hoặc <kbd className="px-1.5 py-0.5 text-xs bg-gray-800 text-gray-400 rounded border border-gray-700">Ctrl+Enter</kbd>
              {' '}để chạy code
            </p>
          </div>
        )}

        {/* Output tab */}
        {!isLoading && result && activeTab === 'output' && (
          <pre className="output-pre text-green-300">
            {result.stdout || (
              <span className="text-gray-600 italic">(no stdout output)</span>
            )}
            {result.timedOut && (
              <span className="block mt-2 text-yellow-400">
                ⏱ Chương trình bị dừng do vượt thời gian giới hạn.
              </span>
            )}
          </pre>
        )}

        {/* Errors tab */}
        {!isLoading && result && activeTab === 'errors' && (
          <div className="p-3 space-y-3">
            {result.compileError && (
              <div>
                <div className="text-xs font-semibold text-red-400 mb-1.5 flex items-center gap-1">
                  <XCircle size={12} /> Compile Error
                </div>
                <pre className="output-pre text-red-300 bg-red-950/20 rounded p-3 text-xs">
                  {result.compileError}
                </pre>
              </div>
            )}
            {result.stderr && (
              <div>
                <div className="text-xs font-semibold text-orange-400 mb-1.5 flex items-center gap-1">
                  <AlertCircle size={12} /> Runtime Stderr
                </div>
                <pre className="output-pre text-orange-300 bg-orange-950/20 rounded p-3 text-xs">
                  {result.stderr}
                </pre>
              </div>
            )}
            {!result.compileError && !result.stderr && (
              <div className="flex items-center gap-2 text-green-400 text-sm p-4">
                <CheckCircle size={16} />
                Không có lỗi nào!
              </div>
            )}
          </div>
        )}

        {/* Info tab */}
        {!isLoading && result && activeTab === 'info' && (
          <div className="p-4 space-y-3 text-sm">
            <InfoRow
              label="Trạng thái compile"
              value={result.compileError ? '❌ Thất bại' : '✅ Thành công'}
              valueClass={result.compileError ? 'text-red-400' : 'text-green-400'}
            />
            <InfoRow
              label="Exit code"
              value={String(result.exitCode)}
              valueClass={result.exitCode === 0 ? 'text-green-400' : 'text-orange-400'}
            />
            <InfoRow
              label="Thời gian chạy"
              value={result.compileError ? 'N/A' : formatDuration(result.runtime)}
              valueClass="text-blue-400"
            />
            <InfoRow
              label="Timeout"
              value={result.timedOut ? '⚠️ Có' : 'Không'}
              valueClass={result.timedOut ? 'text-yellow-400' : 'text-gray-400'}
            />
            <InfoRow
              label="Kích thước stdout"
              value={`${result.stdout.length} chars`}
              valueClass="text-gray-400"
            />
            <InfoRow
              label="Kích thước stderr"
              value={`${result.stderr.length} chars`}
              valueClass="text-gray-400"
            />
          </div>
        )}
      </div>
    </div>
  );
}

// Component nhỏ hiển thị một dòng thông tin
function InfoRow({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-editor-border">
      <span className="text-gray-400 text-xs">{label}</span>
      <span className={`text-xs font-mono font-medium ${valueClass}`}>{value}</span>
    </div>
  );
}