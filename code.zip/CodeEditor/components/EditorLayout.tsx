// components/EditorLayout.tsx
'use client';

/**
 * Component chính chứa toàn bộ giao diện 3-pane editor.
 * Quản lý state: code, input, output, compile status.
 * Auto-save vào localStorage bằng LZMA compression.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'sonner';
import Header from './Header';
import CodeEditor from './CodeEditor';
import InputEditor from './InputEditor';
import OutputPanel from './OutputPanel';
import { debounce, AUTOSAVE_KEY, DEFAULT_CPP_CODE, DEFAULT_INPUT } from '@/lib/utils';

// Kiểu dữ liệu kết quả compile
export interface CompileResult {
  stdout: string;
  stderr: string;
  compileError: string | null;
  exitCode: number;
  runtime: number;
  timedOut: boolean;
}

interface EditorLayoutProps {
  /** Code C++ ban đầu (từ share link hoặc undefined = dùng default/localStorage) */
  initialCode?: string;
  /** Input ban đầu (từ share link hoặc undefined) */
  initialInput?: string;
  /** Đánh dấu đây là trang share */
  isSharedView?: boolean;
}

export default function EditorLayout({
  initialCode,
  initialInput,
  isSharedView = false,
}: EditorLayoutProps) {
  // ───────────── State ─────────────
  const [code, setCode] = useState(initialCode ?? DEFAULT_CPP_CODE);
  const [input, setInput] = useState(initialInput ?? DEFAULT_INPUT);
  const [output, setOutput] = useState<CompileResult | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);
  // true khi đã load xong từ localStorage (tránh auto-save đè mất dữ liệu)
  const [isReady, setIsReady] = useState(false);

  // Ref để track debounce function (stable across renders)
  const autoSaveRef = useRef<ReturnType<typeof debounce> | null>(null);

  // ───────────── Auto-save debounced function ─────────────
  useEffect(() => {
    autoSaveRef.current = debounce(async (c: string, i: string) => {
      try {
        const payload = JSON.stringify({ code: c, input: i });
        // Import động tránh SSR
        const { compressToBase64Url } = await import('@/lib/lzma');
        const compressed = await compressToBase64Url(payload);
        localStorage.setItem(AUTOSAVE_KEY, compressed);
      } catch (err) {
        // Lỗi auto-save không critical – chỉ log
        console.warn('[AutoSave] Thất bại:', err);
      }
    }, 800);
  }, []);

  // ───────────── Load từ localStorage khi khởi động ─────────────
  useEffect(() => {
    // Nếu đã có initialCode/initialInput từ share link → không cần đọc localStorage
    if (initialCode !== undefined || initialInput !== undefined) {
      setIsReady(true);
      return;
    }

    const loadAutoSave = async () => {
      const saved = localStorage.getItem(AUTOSAVE_KEY);
      if (!saved) {
        setIsReady(true);
        return;
      }

      try {
        const { decompressFromBase64Url } = await import('@/lib/lzma');
        const decompressed = await decompressFromBase64Url(saved);
        const parsed = JSON.parse(decompressed);

        if (parsed && typeof parsed === 'object') {
          if (typeof parsed.code === 'string') setCode(parsed.code);
          if (typeof parsed.input === 'string') setInput(parsed.input);
        }
      } catch (err) {
        console.warn('[AutoSave] Đọc localStorage thất bại, xóa cache cũ:', err);
        localStorage.removeItem(AUTOSAVE_KEY);
      } finally {
        setIsReady(true);
      }
    };

    loadAutoSave();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ───────────── Trigger auto-save khi code/input thay đổi ─────────────
  useEffect(() => {
    if (!isReady) return;
    autoSaveRef.current?.(code, input);
  }, [code, input, isReady]);

  // ───────────── Compile & Run ─────────────
  const handleRun = useCallback(async () => {
    if (isCompiling) return;

    setIsCompiling(true);
    setOutput(null);

    try {
      const res = await fetch('/api/compile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, input }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
        toast.error(errData.error || 'Compile request thất bại');
        return;
      }

      const result: CompileResult = await res.json();
      setOutput(result);

      // Toast theo kết quả
      if (result.timedOut) {
        toast.warning('⏱ Timeout! Chương trình chạy quá 10 giây.');
      } else if (result.compileError) {
        toast.error('❌ Compile error! Xem tab Errors.');
      } else if (result.exitCode !== 0) {
        toast.warning(`⚠️ Kết thúc với exit code ${result.exitCode}`);
      } else {
        toast.success(`✅ Chạy thành công (${result.runtime}ms)`);
      }
    } catch (err) {
      console.error('[Run] Network error:', err);
      toast.error('Không thể kết nối server. Kiểm tra Docker đang chạy?');
    } finally {
      setIsCompiling(false);
    }
  }, [code, input, isCompiling]);

  // ───────────── Keyboard shortcut: Ctrl/Cmd + Enter ─────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRun();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleRun]);

  // ───────────── Render ─────────────
  return (
    <div className="flex flex-col h-screen bg-editor-bg overflow-hidden">
      {/* Header */}
      <Header
        code={code}
        input={input}
        output={output}
        isCompiling={isCompiling}
        onRun={handleRun}
        isSharedView={isSharedView}
      />

      {/* 3-pane layout */}
      <div className="flex flex-col lg:flex-row flex-1 overflow-hidden">

        {/* ─── Pane 1: Code Editor (50% desktop) ─── */}
        <div className="
          flex flex-col
          h-[45vh] lg:h-full lg:w-[50%]
          border-b lg:border-b-0 lg:border-r border-editor-border
          overflow-hidden
        ">
          {/* Pane title */}
          <PaneTitle color="bg-red-500">
            <span className="font-mono text-xs text-gray-400">main.cpp</span>
            <span className="text-[10px] text-gray-600">C++20</span>
          </PaneTitle>

          {/* Monaco */}
          <div className="flex-1 overflow-hidden">
            <CodeEditor
              value={code}
              onChange={(val) => setCode(val ?? '')}
              onRun={handleRun}
            />
          </div>
        </div>

        {/* ─── Pane 2 + 3: Input & Output (50% desktop, stacked) ─── */}
        <div className="flex flex-col lg:w-[50%] flex-1 overflow-hidden">

          {/* Pane 2: Input Editor (35% height on desktop) */}
          <div className="
            flex flex-col
            h-[20vh] lg:h-[35%]
            border-b border-editor-border
            overflow-hidden
          ">
            <InputEditor value={input} onChange={setInput} />
          </div>

          {/* Pane 3: Output Panel (65% height on desktop) */}
          <div className="flex flex-col flex-1 lg:h-[65%] overflow-hidden">
            <OutputPanel
              result={output}
              isLoading={isCompiling}
              onClear={() => setOutput(null)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Helper: tiêu đề nhỏ của mỗi pane (3 chấm macOS style) ──
function PaneTitle({
  children,
  color,
}: {
  children: React.ReactNode;
  color: string;
}) {
  return (
    <div className="flex items-center justify-between px-3 py-1.5 bg-[#111118] border-b border-editor-border shrink-0">
      <div className="flex items-center gap-2">
        <span className={`w-2.5 h-2.5 rounded-full ${color} opacity-60`} />
        {children}
      </div>
    </div>
  );
}