// components/ShareButton.tsx
'use client';

/**
 * Nút Share: nén code+input bằng LZMA → tạo URL → copy vào clipboard.
 */

import { useState } from 'react';
import { Share2, Copy, Check, Loader2, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { SHARE_WARN_BYTES } from '@/lib/utils';

interface ShareButtonProps {
  code: string;
  input: string;
}

export default function ShareButton({ code, input }: ShareButtonProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    if (isGenerating) return;

    const payload = JSON.stringify({ code, input });
    const payloadBytes = new TextEncoder().encode(payload).length;

    // Cảnh báo nếu dữ liệu quá lớn
    if (payloadBytes > SHARE_WARN_BYTES) {
      toast.warning(
        `Dữ liệu lớn (${(payloadBytes / 1024).toFixed(1)}KB). URL có thể rất dài.`,
        { duration: 4000 }
      );
    }

    setIsGenerating(true);
    setShareUrl(null);

    try {
      // Import động để tránh SSR
      const { compressToBase64Url } = await import('@/lib/lzma');
      const compressed = await compressToBase64Url(payload);

      const url = `${window.location.origin}/s/${compressed}`;
      setShareUrl(url);

      // Tự động copy vào clipboard
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success('Đã tạo và copy link share!', {
        description: `${url.length} ký tự`,
      });
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Share error:', err);
      toast.error('Tạo link share thất bại. Thử lại sau.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy link đã tạo
  const handleCopyUrl = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success('Đã copy link!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Không thể copy');
    }
  };

  return (
    <div className="flex items-center gap-1">
      {/* Nút tạo share link */}
      <button
        onClick={handleShare}
        disabled={isGenerating}
        title="Tạo link chia sẻ (nén bằng LZMA)"
        className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-60 disabled:cursor-not-allowed text-white text-xs font-medium rounded-md transition-colors"
      >
        {isGenerating ? (
          <Loader2 size={13} className="animate-spin" />
        ) : (
          <Share2 size={13} />
        )}
        {isGenerating ? 'Đang nén...' : 'Share'}
      </button>

      {/* Nút copy link (chỉ hiện sau khi đã tạo link) */}
      {shareUrl && (
        <button
          onClick={handleCopyUrl}
          title={shareUrl}
          className="flex items-center gap-1 px-2 py-1.5 bg-gray-700 hover:bg-gray-600 text-white text-xs rounded-md transition-colors"
        >
          {copied ? (
            <Check size={13} className="text-green-400" />
          ) : (
            <Copy size={13} />
          )}
        </button>
      )}
    </div>
  );
}