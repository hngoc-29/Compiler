// components/Header.tsx
'use client';

/**
 * Header bar: Logo + Run button + Export dropdown + Share button.
 */

import { useState, useRef, useEffect } from 'react';
import {
  Play,
  Loader2,
  Download,
  ChevronDown,
  FileCode,
  FileText,
  FileOutput,
  Cpu,
} from 'lucide-react';
import ShareButton from './ShareButton';
import { downloadTextFile } from '@/lib/utils';
import { toast } from 'sonner';

interface CompileResult {
  stdout: string;
  stderr?: string;
  compileError?: string | null;
  exitCode?: number;
  runtime?: number;
}

interface HeaderProps {
  code: string;
  input: string;
  output: CompileResult | null;
  isCompiling: boolean;
  onRun: () => void;
  isSharedView?: boolean;
}

export default function Header({
  code,
  input,
  output,
  isCompiling,
  onRun,
  isSharedView = false,
}: HeaderProps) {
  const [exportOpen, setExportOpen] = useState(false);
  const exportRef = useRef<HTMLDivElement>(null);

  // Đóng dropdown khi click ra ngoài
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (exportRef.current && !exportRef.current.contains(e.target as Node)) {
        setExportOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Download một file với tên có thể đổi
  const handleDownload = (defaultName: string, content: string, type: string) => {
    const name = window.prompt(`Tên file (${type}):`, defaultName);
    if (name === null) return; // User cancel
    const filename = name.trim() || defaultName;
    downloadTextFile(content, filename);
    toast.success(`Đã tải ${filename}`);
    setExportOpen(false);
  };

  const exportItems = [
    {
      icon: <FileCode size={13} />,
      label: 'main.cpp',
      hint: 'C++ source code',
      onClick: () => handleDownload('main.cpp', code, 'C++'),
    },
    {
      icon: <FileText size={13} />,
      label: 'input.txt',
      hint: 'Stdin input',
      onClick: () => handleDownload('input.txt', input, 'Text'),
    },
    {
      icon: <FileOutput size={13} />,
      label: 'output.txt',
      hint: 'Stdout output',
      disabled: !output,
      onClick: () => {
        if (!output) return;
        handleDownload('output.txt', output.stdout || '', 'Text');
      },
    },
  ];

  return (
    <header className="flex items-center justify-between px-4 py-2 bg-[#0d0d17] border-b border-editor-border shrink-0 z-10">
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div className="p-1 rounded bg-indigo-600/20">
          <Cpu size={18} className="text-indigo-400" />
        </div>
        <span className="text-sm font-bold text-gray-100 tracking-tight">
          CppEditor
        </span>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800 text-gray-500 font-mono">
          C++20
        </span>
        {isSharedView && (
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-violet-900/40 text-violet-400 border border-violet-800/50">
            Shared
          </span>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        {/* Run button */}
        <button
          onClick={onRun}
          disabled={isCompiling}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 disabled:cursor-not-allowed text-white text-xs font-semibold rounded-md transition-colors"
          title="Compile & Run (Ctrl+Enter)"
        >
          {isCompiling ? (
            <Loader2 size={13} className="animate-spin" />
          ) : (
            <Play size={13} />
          )}
          {isCompiling ? 'Running...' : 'Run'}
          <kbd className="ml-1 text-[9px] opacity-50 hidden sm:inline">⌘↵</kbd>
        </button>

        {/* Export dropdown */}
        <div className="relative" ref={exportRef}>
          <button
            onClick={() => setExportOpen((v) => !v)}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-gray-700 hover:bg-gray-600 text-white text-xs font-medium rounded-md transition-colors"
            title="Tải file"
          >
            <Download size={13} />
            <span className="hidden sm:inline">Export</span>
            <ChevronDown
              size={11}
              className={`transition-transform ${exportOpen ? 'rotate-180' : ''}`}
            />
          </button>

          {/* Dropdown menu */}
          {exportOpen && (
            <div className="absolute right-0 top-full mt-1 w-52 bg-[#1a1a2e] border border-editor-border rounded-lg shadow-xl z-50 py-1 animate-fade-in">
              {exportItems.map((item) => (
                <button
                  key={item.label}
                  onClick={item.onClick}
                  disabled={item.disabled}
                  className="flex items-center gap-2.5 w-full px-3 py-2 text-xs text-gray-300 hover:bg-gray-700/50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-left"
                >
                  <span className="text-gray-500">{item.icon}</span>
                  <div>
                    <div className="font-mono font-medium">{item.label}</div>
                    <div className="text-gray-600 text-[10px]">{item.hint}</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Share button */}
        <ShareButton code={code} input={input} />
      </div>
    </header>
  );
}