// components/InputEditor.tsx
'use client';

/**
 * Editor cho stdin input (input.txt).
 * Dùng textarea đơn giản thay vì Monaco để nhẹ hơn.
 */

import { useRef } from 'react';
import { Copy, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface InputEditorProps {
  value: string;
  onChange: (value: string) => void;
}

export default function InputEditor({ value, onChange }: InputEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Copy nội dung input vào clipboard
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success('Đã copy input!');
    } catch {
      toast.error('Không thể copy');
    }
  };

  // Xóa trắng input
  const handleClear = () => {
    onChange('');
    textareaRef.current?.focus();
  };

  // Hỗ trợ Tab trong textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newValue = value.substring(0, start) + '  ' + value.substring(end);
      onChange(newValue);
      // Di chuyển con trỏ sau tab
      requestAnimationFrame(() => {
        ta.selectionStart = start + 2;
        ta.selectionEnd = start + 2;
      });
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Thanh tiêu đề */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#111118] border-b border-editor-border shrink-0">
        <div className="flex items-center gap-2">
          {/* Chấm màu giống macOS */}
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500 opacity-70" />
          <span className="text-xs font-medium text-gray-400 font-mono">input.txt</span>
          {/* Hiển thị số byte */}
          {value.length > 0 && (
            <span className="text-[10px] text-gray-600">
              {value.length} chars
            </span>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleCopy}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title="Copy input"
          >
            <Copy size={12} />
          </button>
          <button
            onClick={handleClear}
            className="p-1 rounded hover:bg-gray-700 text-gray-500 hover:text-gray-300 transition-colors"
            title="Xóa input"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      {/* Textarea */}
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Nhập stdin input ở đây...&#10;(nội dung này sẽ được truyền vào cin)"
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        className="code-textarea flex-1"
        style={{
          fontFamily: 'var(--font-mono), JetBrains Mono, Consolas, monospace',
          fontSize: '13px',
        }}
      />
    </div>
  );
}