// components/CodeEditor.tsx
'use client';

/**
 * Monaco Editor wrapper cho C++ code.
 * Sử dụng dynamic import (ssr: false) vì Monaco không hỗ trợ SSR.
 */

import dynamic from 'next/dynamic';
import { useRef } from 'react';
import { Loader2 } from 'lucide-react';

// Import Monaco không SSR
const MonacoEditor = dynamic(
  () => import('@monaco-editor/react').then((mod) => mod.default),
  {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-full bg-[#0d0d15]">
        <Loader2 size={24} className="animate-spin text-indigo-400" />
      </div>
    ),
  }
);

interface CodeEditorProps {
  value: string;
  onChange: (value: string | undefined) => void;
  onRun: () => void;
  readOnly?: boolean;
}

export default function CodeEditor({
  value,
  onChange,
  onRun,
  readOnly = false,
}: CodeEditorProps) {
  // Ref để truy cập editor instance
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const editorRef = useRef<any>(null);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleMount = (editor: any, monaco: any) => {
    editorRef.current = editor;

    // Thêm keybinding Ctrl+Enter / Cmd+Enter để Run
    editor.addCommand(
      monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter,
      () => {
        onRun();
      }
    );

    // Focus vào editor khi mount
    editor.focus();
  };

  return (
    <div className="h-full w-full">
      <MonacoEditor
        height="100%"
        language="cpp"
        theme="vs-dark"
        value={value}
        onChange={onChange}
        onMount={handleMount}
        options={{
          // Font và style
          fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
          fontSize: 13,
          fontLigatures: true,
          lineHeight: 22,

          // UI
          minimap: { enabled: false },
          scrollBeyondLastLine: false,
          renderWhitespace: 'selection',
          wordWrap: 'off',
          tabSize: 4,
          insertSpaces: true,

          // Tính năng
          readOnly,
          folding: true,
          bracketPairColorization: { enabled: true },
          autoClosingBrackets: 'always',
          autoClosingQuotes: 'always',
          formatOnPaste: false,
          suggestOnTriggerCharacters: true,

          // Scroll
          smoothScrolling: true,
          cursorBlinking: 'smooth',
          cursorSmoothCaretAnimation: 'on',

          // Padding
          padding: { top: 12, bottom: 12 },

          // Số dòng
          lineNumbers: 'on',
          lineDecorationsWidth: 8,
          lineNumbersMinChars: 3,
        }}
      />
    </div>
  );
}