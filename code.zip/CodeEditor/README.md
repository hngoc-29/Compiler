# README.md
# CppEditor – C++ Online Compiler

Trình soạn thảo và biên dịch C++ online với giao diện 3-pane, share link bằng LZMA compression.

## ✨ Tính năng

- **Monaco Editor** cho C++ với syntax highlighting, autocomplete
- **Compile thật** bằng `g++ -std=c++20` trong Docker container
- **Share link** bằng LZMA compression (không cần database)
- **Auto-save** vào localStorage với debounce 800ms
- **Dark mode** mặc định, responsive trên mobile
- **Export** file: main.cpp, input.txt, output.txt

---

## 🛠 Chạy locally (Development)

### Yêu cầu
- Node.js 20+
- g++ được cài trên máy (để compile C++)

```bash
# Cài dependencies
npm install

# Chạy dev server
npm run dev
```

Truy cập: http://localhost:3000

---

## 🐳 Chạy bằng Docker (Recommended)

### Build image

```bash
# Build multi-stage Docker image
docker build -t cppeditor:latest .
```

### Chạy container

```bash
# Chạy với port 3000
docker run -p 3000:3000 cppeditor:latest
```

Truy cập: http://localhost:3000

### Chạy ở background

```bash
docker run -d \
  --name cppeditor \
  -p 3000:3000 \
  --restart unless-stopped \
  cppeditor:latest
```

### Xem logs

```bash
docker logs -f cppeditor
```

### Dừng và xóa container

```bash
docker stop cppeditor && docker rm cppeditor
```

---

## 🚀 Deploy lên Render.com

### Cách 1: Deploy từ GitHub

1. Push code lên GitHub repository.

2. Vào [Render Dashboard](https://dashboard.render.com) → **New** → **Web Service**.

3. Kết nối với GitHub repo của bạn.

4. Cài đặt:
   - **Environment**: `Docker`
   - **Branch**: `main`
   - **Port**: `3000`

5. Render sẽ tự động build Dockerfile và deploy.

### Cách 2: Deploy từ Dockerfile trực tiếp

1. Trong Render → **New Web Service** → chọn **Deploy from a Git repository** hoặc **Deploy a Docker image**.

2. Chỉnh **Dockerfile Path** về `./Dockerfile`.

3. Environment variables (nếu cần):