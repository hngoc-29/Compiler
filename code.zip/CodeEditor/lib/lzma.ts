// lib/lzma.ts
/**
 * Tiện ích nén/giải nén LZMA bằng lzma-web.
 * CHỈ DÙNG Ở CLIENT-SIDE (browser). Không gọi từ server component.
 *
 * Dữ liệu được encode sang base64url (URL-safe) để nhúng vào URL path.
 */

// Lazy-load LZMA instance, tránh khởi tạo lại nhiều lần
let lzmaInstance: LZMAInstance | null = null;

// Định nghĩa kiểu cho lzma-web (package không có built-in types)
interface LZMAInstance {
  compress(
    data: string,
    mode: number,
    onFinish: (result: number[] | null, error: unknown) => void,
    onProgress?: (percent: number) => void
  ): void;
  decompress(
    data: number[] | Uint8Array,
    onFinish: (result: string | null, error: unknown) => void,
    onProgress?: (percent: number) => void
  ): void;
}

/**
 * Lấy LZMA instance, lazy-load khi cần lần đầu.
 */
async function getLZMA(): Promise<LZMAInstance> {
  if (lzmaInstance) return lzmaInstance;

  if (typeof window === 'undefined') {
    throw new Error('LZMA chỉ khả dụng ở browser (client-side).');
  }

  // Dynamic import để tránh SSR issues
  const mod = await import('lzma-web');
  // lzma-web có thể export default hoặc named
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const LZMA = (mod as any).default ?? mod;
  // Tạo instance không có worker path → chạy synchronous trong main thread
  lzmaInstance = new LZMA() as LZMAInstance;
  return lzmaInstance;
}

/**
 * Chuyển Uint8Array sang chuỗi base64url (URL-safe, không có ký tự đặc biệt).
 * Thay: + → -, / → _, bỏ ký tự padding =
 */
function uint8ArrayToBase64Url(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/**
 * Chuyển chuỗi base64url về mảng số (byte array).
 */
function base64UrlToNumberArray(base64url: string): number[] {
  // Khôi phục ký tự base64 gốc
  const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
  // Thêm padding nếu thiếu
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const result: number[] = new Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    result[i] = binary.charCodeAt(i);
  }
  return result;
}

/**
 * Nén chuỗi data bằng LZMA level 9, trả về chuỗi base64url.
 *
 * @param data - Chuỗi cần nén (thường là JSON.stringify của { code, input })
 * @returns Chuỗi base64url chứa dữ liệu đã nén
 */
export async function compressToBase64Url(data: string): Promise<string> {
  const lzma = await getLZMA();

  return new Promise((resolve, reject) => {
    lzma.compress(
      data,
      9, // Level nén cao nhất (1–9)
      (result: number[] | null, error: unknown) => {
        if (error || !result) {
          reject(new Error(error ? String(error) : 'LZMA compress trả về null'));
          return;
        }
        try {
          const bytes = new Uint8Array(result);
          resolve(uint8ArrayToBase64Url(bytes));
        } catch (err) {
          reject(err);
        }
      }
    );
  });
}

/**
 * Giải nén chuỗi base64url (LZMA) về string gốc.
 *
 * @param base64url - Chuỗi base64url đã nén
 * @returns Chuỗi gốc trước khi nén
 */
export async function decompressFromBase64Url(base64url: string): Promise<string> {
  if (!base64url || typeof base64url !== 'string') {
    throw new Error('Input không hợp lệ: cần chuỗi base64url');
  }

  const lzma = await getLZMA();

  let byteArray: number[];
  try {
    byteArray = base64UrlToNumberArray(base64url);
  } catch (err) {
    throw new Error(`Lỗi decode base64url: ${err}`);
  }

  return new Promise((resolve, reject) => {
    lzma.decompress(
      byteArray,
      (result: string | null, error: unknown) => {
        if (error) {
          reject(new Error(`LZMA decompress lỗi: ${error}`));
          return;
        }
        if (result === null || result === undefined) {
          reject(new Error('LZMA decompress trả về null/undefined'));
          return;
        }
        resolve(result);
      }
    );
  });
}