// lib/compiler.ts
/**
 * Logic compile và chạy C++ bằng g++.
 * Chạy trong Node.js runtime (API route), KHÔNG dùng ở browser.
 */

import { spawn } from 'child_process';
import { writeFile, unlink } from 'fs/promises';
import { join } from 'path';
import { randomUUID } from 'crypto';
import os from 'os';

export interface CompileResult {
  /** Nội dung stdout của chương trình */
  stdout: string;
  /** Nội dung stderr khi chạy (runtime warnings/errors) */
  stderr: string;
  /** Lỗi compile (null nếu compile thành công) */
  compileError: string | null;
  /** Exit code của chương trình (0 = success) */
  exitCode: number;
  /** Thời gian chạy tính bằng millisecond */
  runtime: number;
  /** true nếu chương trình bị kill do quá thời gian */
  timedOut: boolean;
}

// Giới hạn kích thước output để tránh OOM
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024; // 2MB
// Timeout cho bước compile (không liên quan đến timeout chạy)
const COMPILE_TIMEOUT_MS = 30_000;

/**
 * Spawn một process, gửi stdin, thu thập stdout/stderr.
 * Tự động kill khi timeout.
 */
function runProcess(
  cmd: string,
  args: string[],
  stdinData: string,
  timeoutMs: number
): Promise<{
  stdout: string;
  stderr: string;
  exitCode: number;
  timedOut: boolean;
}> {
  return new Promise((resolve) => {
    const proc = spawn(cmd, args, {
      // Không dùng shell để tránh injection
      shell: false,
    });

    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let settled = false;

    // Timeout: gửi SIGTERM trước, sau 1s thì SIGKILL
    const timer = setTimeout(() => {
      timedOut = true;
      proc.kill('SIGTERM');
      setTimeout(() => {
        try { proc.kill('SIGKILL'); } catch {}
      }, 1000);
    }, timeoutMs);

    // Ghi stdin nếu có
    if (stdinData) {
      try {
        proc.stdin.write(stdinData, 'utf-8', () => {
          proc.stdin.end();
        });
      } catch {
        proc.stdin.end();
      }
    } else {
      proc.stdin.end();
    }

    proc.stdout.on('data', (chunk: Buffer) => {
      if (stdout.length < MAX_OUTPUT_BYTES) {
        stdout += chunk.toString('utf-8');
      }
    });

    proc.stderr.on('data', (chunk: Buffer) => {
      if (stderr.length < MAX_OUTPUT_BYTES) {
        stderr += chunk.toString('utf-8');
      }
    });

    const finish = (code: number) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ stdout, stderr, exitCode: code, timedOut });
    };

    proc.on('close', (code) => finish(code ?? -1));
    proc.on('error', (err) => {
      stderr += `\nProcess error: ${err.message}`;
      finish(-1);
    });
  });
}

/**
 * Compile C++ code bằng g++ và chạy với stdin được cấp.
 *
 * @param code     - Nội dung file .cpp
 * @param input    - Nội dung stdin (input.txt)
 * @param timeoutMs - Timeout chạy chương trình (ms)
 */
export async function compileAndRun(
  code: string,
  input: string,
  timeoutMs = 10_000
): Promise<CompileResult> {
  // Tạo tên file unique để tránh race condition khi nhiều request đồng thời
  const id = randomUUID();
  const tmpDir = os.tmpdir();
  const srcFile = join(tmpDir, `cppeditor_${id}.cpp`);
  const binFile = join(tmpDir, `cppeditor_${id}.out`);

  try {
    // === BƯỚC 1: Ghi source code ra file tạm ===
    await writeFile(srcFile, code, { encoding: 'utf-8', mode: 0o644 });

    // === BƯỚC 2: Compile với g++ C++20 ===
    const compileRes = await runProcess(
      'g++',
      [
        '-std=c++20',   // C++20
        '-O2',          // Optimize
        '-Wall',        // Cảnh báo
        '-Wextra',      // Thêm cảnh báo
        '-o', binFile,
        srcFile,
      ],
      '',
      COMPILE_TIMEOUT_MS
    );

    // Compile lỗi
    if (compileRes.exitCode !== 0) {
      return {
        stdout: '',
        stderr: '',
        compileError: compileRes.stderr || 'Compilation failed (no error output)',
        exitCode: compileRes.exitCode,
        runtime: 0,
        timedOut: false,
      };
    }

    // === BƯỚC 3: Chạy binary với stdin ===
    const startTime = Date.now();
    const runRes = await runProcess(binFile, [], input, timeoutMs);
    const runtime = Date.now() - startTime;

    return {
      stdout: runRes.stdout,
      stderr: runRes.stderr,
      compileError: null,
      exitCode: runRes.exitCode,
      runtime,
      timedOut: runRes.timedOut,
    };
  } finally {
    // === BƯỚC 4: Dọn file tạm (dù thành công hay thất bại) ===
    await Promise.allSettled([
      unlink(srcFile).catch(() => {}),
      unlink(binFile).catch(() => {}),
    ]);
  }
}