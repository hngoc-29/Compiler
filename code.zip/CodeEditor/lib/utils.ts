// lib/utils.ts
/**
 * Các hàm tiện ích dùng chung trong ứng dụng.
 */

// ===== Debounce =====

/**
 * Debounce: chỉ gọi fn sau `delay` ms kể từ lần cuối được gọi.
 * Dùng cho auto-save để tránh lưu liên tục.
 */
export function debounce<T extends (...args: Parameters<T>) => void>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout> | null = null;

  return function (...args: Parameters<T>) {
    if (timer !== null) clearTimeout(timer);
    timer = setTimeout(() => {
      fn(...args);
      timer = null;
    }, delay);
  };
}

// ===== Format helpers =====

/**
 * Format milliseconds sang dạng dễ đọc.
 * VD: 1234 → "1.23s", 500 → "500ms"
 */
export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

/**
 * Format bytes sang dạng dễ đọc.
 * VD: 102400 → "100.0 KB"
 */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ===== Giới hạn kích thước =====

export const MAX_CODE_BYTES = 100 * 1024;   // 100KB - code C++
export const MAX_INPUT_BYTES = 10 * 1024;   // 10KB  - stdin input
export const SHARE_WARN_BYTES = 50 * 1024;  // 50KB  - cảnh báo trước khi share

// ===== LocalStorage key =====
export const AUTOSAVE_KEY = 'cppeditor_autosave_v1';

// ===== Download helper =====

/**
 * Tạo file và trigger download trong trình duyệt.
 */
export function downloadTextFile(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ===== C++ Default Template =====

export const DEFAULT_CPP_CODE = `#include <bits/stdc++.h>
using namespace std;

/*
 * Fast I/O template cho competitive programming
 * Thêm: ios_base::sync_with_stdio(false); cin.tie(NULL);
 */

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // ── Viết code của bạn ở đây ──

    int n;
    cin >> n;

    cout << "Hello, CppEditor!" << endl;
    cout << "n = " << n << endl;

    return 0;
}
`;

export const DEFAULT_INPUT = `5
`;