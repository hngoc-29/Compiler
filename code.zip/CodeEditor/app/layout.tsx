// app/layout.tsx
import type { Metadata } from 'next';
import { JetBrains_Mono } from 'next/font/google';
import { Toaster } from 'sonner';
import './globals.css';

// Font monospace chuyên dụng cho code
const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'CppEditor – C++ Online Compiler',
  description:
    'Trình soạn thảo và biên dịch C++ online. Hỗ trợ C++20, chia sẻ code bằng link nén LZMA.',
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    // Thêm class "dark" để kích hoạt dark mode mặc định
    <html lang="vi" className="dark" suppressHydrationWarning>
      <body className={`${jetbrainsMono.variable} bg-editor-bg text-gray-100 antialiased`}>
        {children}

        {/* Toast notification ở góc dưới phải */}
        <Toaster
          theme="dark"
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#1a1a2e',
              border: '1px solid #2a2a4e',
              color: '#e2e8f0',
            },
          }}
        />
      </body>
    </html>
  );
}