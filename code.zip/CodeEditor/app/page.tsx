// app/page.tsx
// Server Component – chỉ render EditorLayout, không có state
import EditorLayout from '@/components/EditorLayout';

export default function HomePage() {
  return <EditorLayout />;
}