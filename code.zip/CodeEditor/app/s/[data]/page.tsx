// app/s/[data]/page.tsx
'use client';

/**
 * Trang share – nhận chuỗi LZMA từ URL param,
 * giải nén rồi render editor với code/input đã được fill sẵn.
 */

import { use, useEffect, useState } from 'react';
import { Loader2, AlertTriangle, Home } from 'lucide-react';
import EditorLayout from '@/components/EditorLayout';

// Next.js 15: params là Promise, cần dùng React.use() trong client component
interface PageProps {
  params: Promise<{ data: string }>;
}

export default function SharePage({ params }: PageProps) {
  const { data } = use(params);

  const [initialCode, setInitialCode] = useState<string | undefined>(undefined);
  const [initialInput, setInitialInput] = useState<string | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);
  const [isDecoding, setIsDecoding] = useState(true);

  useEffect(() => {
    if (!data) {
      setError('Không có dữ liệu trong URL.');
      setIsDecoding(false);
      return;
    }

    const decode = async () => {
      try {
        // Import động để tránh SSR – LZMA chỉ chạy ở browser
        const { decompressFromBase64Url } = await import('@/lib/lzma');
        const decompressed = await decompressFromBase64Url(data);
        const parsed = JSON.parse(decompressed);

        if (typeof parsed !== 'object' || parsed === null) {
          throw new Error('Dữ liệu không đúng định dạng');
        }

        setInitialCode(typeof parsed.code === 'string' ? parsed.code : '');
        setInitialInput(typeof parsed.input === 'string' ? parsed.input : '');
      } catch (err) {
        console.error('Decode share data error:', err);
        setError(
          'Không thể giải mã dữ liệu. Link có thể đã bị hỏng hoặc không hợp lệ.'
        );
      } finally {
        setIsDecoding(false);
      }
    };

    decode();
  }, [data]);

  // Trạng thái đang giải mã
  if (isDecoding) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-editor-bg text-gray-300 gap-4">
        <Loader2 size={32} className="animate-spin text-indigo-400" />
        <p className="text-sm">Đang giải nén dữ liệu từ link share...</p>
      </div>
    );
  }

  // Trạng thái lỗi
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-editor-bg text-gray-300 gap-6 p-8">
        <AlertTriangle size={40} className="text-red-400" />
        <div className="text-center">
          <h2 className="text-lg font-semibold text-red-400 mb-2">Lỗi giải mã</h2>
          <p className="text-sm text-gray-400 max-w-md">{error}</p>
        </div>
        
          href="/"
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-sm transition-colors"
        >
          <Home size={16} />
          Về trang chính
        </a>
      </div>
    );
  }

  // Render editor với dữ liệu đã được fill sẵn
  return (
    <EditorLayout
      initialCode={initialCode}
      initialInput={initialInput}
      isSharedView
    />
  );
}