// app/api/compile/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { compileAndRun } from '@/lib/compiler';

// Giới hạn kích thước để tránh abuse
const MAX_CODE_BYTES = 100 * 1024;  // 100KB
const MAX_INPUT_BYTES = 10 * 1024;  // 10KB
const RUN_TIMEOUT_MS = 10_000;      // 10 giây

export async function POST(req: NextRequest) {
  try {
    // Parse JSON body
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }

    if (typeof body !== 'object' || body === null) {
      return NextResponse.json({ error: 'Body phải là object' }, { status: 400 });
    }

    const { code, input = '' } = body as { code: unknown; input?: unknown };

    // Validate
    if (typeof code !== 'string' || code.trim() === '') {
      return NextResponse.json({ error: 'Trường "code" là bắt buộc và phải là string' }, { status: 400 });
    }

    if (typeof input !== 'string') {
      return NextResponse.json({ error: 'Trường "input" phải là string' }, { status: 400 });
    }

    if (Buffer.byteLength(code, 'utf-8') > MAX_CODE_BYTES) {
      return NextResponse.json(
        { error: `Code quá lớn (tối đa ${MAX_CODE_BYTES / 1024}KB)` },
        { status: 413 }
      );
    }

    if (Buffer.byteLength(input, 'utf-8') > MAX_INPUT_BYTES) {
      return NextResponse.json(
        { error: `Input quá lớn (tối đa ${MAX_INPUT_BYTES / 1024}KB)` },
        { status: 413 }
      );
    }

    // Compile và chạy
    const result = await compileAndRun(code, input, RUN_TIMEOUT_MS);

    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    // Lỗi không mong đợi
    console.error('[API /compile] Unexpected error:', err);
    return NextResponse.json(
      { error: 'Internal server error. Kiểm tra log server.' },
      { status: 500 }
    );
  }
}